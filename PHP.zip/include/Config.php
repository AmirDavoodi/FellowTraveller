<?php
 
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "mc@usi");
define("DB_DATABASE", "FellowTraveler");
?>