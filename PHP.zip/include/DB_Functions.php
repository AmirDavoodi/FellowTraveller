<?php

/**
 * @author Amir
 */

class DB_Functions {

    private $conn;

    // constructor
    function __construct() {
        require_once 'DB_Connect.php';
        // connecting to database
        $db = new Db_Connect();
        $this->conn = $db->connect();
    }

    // destructor
    function __destruct() {

    }

    /**
     * Storing new user
     * returns user details
     */
    public function storeUser($name, $email, $password, $phone) {
        $uuid = uniqid('', true);
        $hash = $this->hashSSHA($password);
        $encrypted_password = $hash["encrypted"]; // encrypted password
        $salt = $hash["salt"]; // salt

        $stmt = $this->conn->prepare("INSERT INTO Users(unique_id, name, email, encrypted_password, salt, phone, created_at) VALUES(?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("ssssss", $uuid, $name, $email, $encrypted_password, $salt, $phone);
        $result = $stmt->execute();
        $stmt->close();

        // check for successful store
        if ($result) {
            $stmt = $this->conn->prepare("SELECT * FROM Users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            return $user;
        } else {
            return false;
        }
    }

    /**
     * Storing new path
     * returns path details
     */
    public function storeUser($uuid, $originAddress, $originLat, $originLng, $destinationAddress, $destinationLat, $destinationLng) {
        $originPosition = $this->conn->prepare("INSERT INTO positions(lat, lng, address) VALUES(?, ?, ?)");
        $originPosition->bind_param("dds", $originLat, $originLng, $originAddress);
        $result = $originPosition->execute();
        $originPosition->close();

        // check for successful origin Position store
        if ($originResult) {
            $originPositionId = $result;
            // store destination position
            $desPosition = $this->conn->prepare("INSERT INTO positions(lat, lng, address) VALUES(?, ?, ?)");
            $desPosition->bind_param("dds", $destinationLat, $destinationLng, $destinationAddress);
            $desResult = $desPosition->execute();
            $desPosition->close();

            // check for successful destination Position store
            if ($desResult) {
              $desPositionId = $desResult;
              // store path
              $path = $this->conn->prepare("INSERT INTO Path(source_p, destination_p) VALUES(?, ?)");
              $path->bind_param("ii", $originPositionId, $desPositionId);
              $pathResult = $path->execute();
              $path->close();

              // check for path
              if ($pathResult) {
                  $pathId = $pathResult;
                  // store trip
                  $trips = $this->conn->prepare("INSERT INTO trips(user_id, travel_id, my_path, created_at) VALUES(?, ?, ?, NOW())");
                  $path->bind_param("iii", $originPositionId, $desPositionId);
                  $pathResult = $path->execute();
                  $path->close();

              }else {
                return FALSE;
              }
            }else {
              return false;
            }
            return false;

        } else {
            return false;
        }
    }

    /**
     * Get user by email and password
     */
    public function getUserByEmailAndPassword($email, $password) {

        $stmt = $this->conn->prepare("SELECT * FROM Users WHERE email = ?");

        $stmt->bind_param("s", $email);

        if ($stmt->execute()) {
            $user = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            // verifying user password
            $salt = $user['salt'];
            $encrypted_password = $user['encrypted_password'];
            $hash = $this->checkhashSSHA($salt, $password);
            // check for password equality
            if ($encrypted_password == $hash) {
                // user authentication details are correct
                return $user;
            }
        } else {
            return NULL;
        }
    }

    /**
     * Check user is existed or not
     */
    public function isUserExisted($email) {
        $stmt = $this->conn->prepare("SELECT email from Users WHERE email = ?");

        $stmt->bind_param("s", $email);

        $stmt->execute();

        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            // user existed
            $stmt->close();
            return true;
        } else {
            // user not existed
            $stmt->close();
            return false;
        }
    }

    /**
     * Encrypting password
     * @param password
     * returns salt and encrypted password
     */
    public function hashSSHA($password) {

        $salt = sha1(rand());
        $salt = substr($salt, 0, 10);
        $encrypted = base64_encode(sha1($password . $salt, true) . $salt);
        $hash = array("salt" => $salt, "encrypted" => $encrypted);
        return $hash;
    }

    /**
     * Decrypting password
     * @param salt, password
     * returns hash string
     */
    public function checkhashSSHA($salt, $password) {

        $hash = base64_encode(sha1($password . $salt, true) . $salt);

        return $hash;
    }

}

?>
